import { useState, useEffect, useCallback } from "react";

// ============================================================
// DATA
// ============================================================
const VOCABULARY = [
  { word: "Ambitious", translation: "Амбициозный", example: "She is very ambitious.", level: "B1" },
  { word: "Eloquent", translation: "Красноречивый", example: "He gave an eloquent speech.", level: "B2" },
  { word: "Persevere", translation: "Настойчиво продолжать", example: "You must persevere to succeed.", level: "B2" },
  { word: "Diligent", translation: "Прилежный", example: "A diligent student always studies.", level: "B1" },
  { word: "Flourish", translation: "Процветать", example: "Plants flourish in sunlight.", level: "B2" },
  { word: "Innovative", translation: "Инновационный", example: "They have innovative ideas.", level: "B1" },
  { word: "Curious", translation: "Любопытный", example: "Children are naturally curious.", level: "A2" },
  { word: "Resilient", translation: "Стойкий", example: "She is resilient under pressure.", level: "C1" },
  { word: "Venture", translation: "Предприятие", example: "It was a risky venture.", level: "B2" },
  { word: "Profound", translation: "Глубокий", example: "A profound change occurred.", level: "C1" },
];

const GRAMMAR_LESSONS = [
  {
    id: 1,
    title: "Present Simple",
    icon: "⚡",
    level: "A1",
    theory: "Present Simple используется для регулярных действий, фактов и расписаний. Структура: Subject + V1 (he/she/it + V1+s)",
    examples: ["I work every day.", "She plays tennis on Sundays.", "The sun rises in the east."],
    exercises: [
      { q: "She ___ (work) at a hospital.", answer: "works", options: ["work", "works", "worked", "working"] },
      { q: "They ___ (play) football every weekend.", answer: "play", options: ["plays", "play", "played", "playing"] },
      { q: "He ___ (read) books in the evening.", answer: "reads", options: ["read", "reads", "reading", "readed"] },
    ]
  },
  {
    id: 2,
    title: "Past Simple",
    icon: "⏪",
    level: "A2",
    theory: "Past Simple используется для завершённых действий в прошлом. Структура: Subject + V2 (для правильных глаголов: V1+ed)",
    examples: ["I worked yesterday.", "She played tennis last week.", "They visited Paris in 2022."],
    exercises: [
      { q: "I ___ (visit) my grandmother yesterday.", answer: "visited", options: ["visit", "visits", "visited", "visiting"] },
      { q: "She ___ (study) hard for the exam.", answer: "studied", options: ["study", "studies", "studied", "studying"] },
      { q: "They ___ (travel) to Italy last summer.", answer: "travelled", options: ["travel", "travels", "travelled", "travelling"] },
    ]
  },
  {
    id: 3,
    title: "Present Perfect",
    icon: "✅",
    level: "B1",
    theory: "Present Perfect связывает прошлое с настоящим. Структура: Subject + have/has + V3 (причастие прошедшего времени)",
    examples: ["I have just finished my work.", "She has never been to London.", "They have lived here for 10 years."],
    exercises: [
      { q: "I ___ (finish) my homework.", answer: "have finished", options: ["finished", "have finished", "has finished", "finish"] },
      { q: "She ___ (never / see) the ocean.", answer: "has never seen", options: ["never saw", "has never seen", "have never seen", "never sees"] },
      { q: "We ___ (live) here since 2015.", answer: "have lived", options: ["lived", "live", "has lived", "have lived"] },
    ]
  },
  {
    id: 4,
    title: "Conditionals",
    icon: "🔀",
    level: "B2",
    theory: "Условные предложения выражают условия и результаты. 1st: If + Present Simple, will + V1. 2nd: If + Past Simple, would + V1.",
    examples: ["If it rains, I will stay home.", "If I were rich, I would travel the world.", "If you study, you will pass."],
    exercises: [
      { q: "If I ___ (have) time, I will call you.", answer: "have", options: ["have", "had", "has", "having"] },
      { q: "If she ___ (be) taller, she would be a model.", answer: "were", options: ["is", "was", "were", "be"] },
      { q: "I would travel if I ___ (have) more money.", answer: "had", options: ["have", "has", "had", "having"] },
    ]
  },
];

const DIALOGUES = [
  {
    id: 1,
    title: "At the Airport ✈️",
    level: "A2",
    lines: [
      { speaker: "Officer", text: "Good morning! May I see your passport, please?" },
      { speaker: "You", text: "Of course! Here it is." },
      { speaker: "Officer", text: "What is the purpose of your visit?" },
      { speaker: "You", text: "I'm here for tourism. I'd like to visit the main sights." },
      { speaker: "Officer", text: "How long will you be staying?" },
      { speaker: "You", text: "About two weeks. I fly back on the 20th." },
      { speaker: "Officer", text: "Enjoy your stay! Welcome!" },
    ]
  },
  {
    id: 2,
    title: "Job Interview 💼",
    level: "B1",
    lines: [
      { speaker: "Interviewer", text: "Thank you for coming in today. Can you tell me about yourself?" },
      { speaker: "You", text: "Sure! I have 3 years of experience in marketing and I love creative challenges." },
      { speaker: "Interviewer", text: "What are your greatest strengths?" },
      { speaker: "You", text: "I'm very organized, a strong communicator, and I work well under pressure." },
      { speaker: "Interviewer", text: "Where do you see yourself in 5 years?" },
      { speaker: "You", text: "I'd like to be in a leadership role, managing a team and driving strategy." },
    ]
  },
];

const LEVEL_TEST = [
  { q: "I ___ a student.", options: ["am", "is", "are", "be"], answer: "am", level: "A1" },
  { q: "She ___ to school every day.", options: ["go", "goes", "going", "went"], answer: "goes", level: "A1" },
  { q: "They were eating dinner when I ___.", options: ["arrived", "arrive", "arriving", "arrives"], answer: "arrived", level: "A2" },
  { q: "I have ___ been to Japan.", options: ["never", "ever", "always", "yet"], answer: "never", level: "B1" },
  { q: "If I ___ you, I would apologize.", options: ["were", "am", "was", "be"], answer: "were", level: "B2" },
  { q: "She insisted that he ___ the truth.", options: ["tell", "tells", "told", "telling"], answer: "tell", level: "C1" },
  { q: "The project ___ by the time we arrived.", options: ["had been completed", "was completed", "completed", "has completed"], answer: "had been completed", level: "C1" },
];

const ACHIEVEMENTS = [
  { id: "first_lesson", icon: "🎯", title: "Первый урок", desc: "Завершите первый урок", xp: 50 },
  { id: "vocab_10", icon: "📚", title: "Словарник", desc: "Выучите 10 слов", xp: 100 },
  { id: "streak_3", icon: "🔥", title: "На огне!", desc: "3 дня подряд", xp: 150 },
  { id: "perfect_quiz", icon: "⭐", title: "Перфекционист", desc: "100% в тесте", xp: 200 },
  { id: "all_grammar", icon: "🏆", title: "Мастер грамматики", desc: "Все уроки грамматики", xp: 500 },
];

// ============================================================
// MAIN APP
// ============================================================
export default function EnglishApp() {
  const [screen, setScreen] = useState("home"); // home | test | grammar | vocab | dialogue | profile
  const [xp, setXp] = useState(320);
  const [streak, setStreak] = useState(5);
  const [level, setLevel] = useState("B1");
  const [unlockedAchievements, setUnlockedAchievements] = useState(["first_lesson"]);
  const [completedLessons, setCompletedLessons] = useState([1]);
  const [vocabLearned, setVocabLearned] = useState([0, 1, 2]);
  const [notification, setNotification] = useState(null);

  const showNotif = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 2500);
  };

  const addXp = useCallback((amount) => {
    setXp(prev => {
      showNotif(`+${amount} XP заработано! 🎉`);
      return prev + amount;
    });
  }, []);

  const unlockAchievement = useCallback((id) => {
    if (!unlockedAchievements.includes(id)) {
      setUnlockedAchievements(prev => [...prev, id]);
      const ach = ACHIEVEMENTS.find(a => a.id === id);
      if (ach) showNotif(`🏆 Достижение: ${ach.title}!`);
    }
  }, [unlockedAchievements]);

  const xpToNextLevel = 500;
  const xpProgress = (xp % xpToNextLevel) / xpToNextLevel * 100;
  const userLevel = Math.floor(xp / xpToNextLevel) + 1;

  return (
    <div style={{
      fontFamily: "'Georgia', serif",
      background: "linear-gradient(135deg, #0a0a1a 0%, #0d1b2e 50%, #0a0a1a 100%)",
      minHeight: "100vh",
      color: "#e8e0d0",
      maxWidth: 480,
      margin: "0 auto",
      position: "relative",
      overflowX: "hidden",
    }}>
      {/* Background decoration */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        background: "radial-gradient(ellipse at 20% 20%, rgba(255,180,50,0.04) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(100,180,255,0.04) 0%, transparent 60%)"
      }} />

      {notification && (
        <div style={{
          position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)",
          background: notification.type === "success" ? "linear-gradient(135deg, #1a3a1a, #2d5a2d)" : "linear-gradient(135deg, #3a1a1a, #5a2d2d)",
          border: "1px solid rgba(255,180,50,0.4)",
          borderRadius: 12, padding: "12px 24px",
          color: "#f0c060", fontWeight: "bold", fontSize: 14,
          zIndex: 9999, boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
          animation: "slideDown 0.3s ease",
          whiteSpace: "nowrap",
        }}>
          {notification.msg}
        </div>
      )}

      <style>{`
        @keyframes slideDown { from { transform: translateX(-50%) translateY(-20px); opacity:0; } to { transform: translateX(-50%) translateY(0); opacity:1; } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.7; } }
        @keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,180,50,0.3); border-radius: 2px; }
      `}</style>

      {/* Header */}
      <div style={{
        position: "sticky", top: 0, zIndex: 100,
        background: "rgba(10,10,26,0.95)", backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,180,50,0.15)",
        padding: "12px 20px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 24 }}>🇬🇧</span>
          <div>
            <div style={{ fontSize: 16, fontWeight: "bold", color: "#f0c060", letterSpacing: 1 }}>EnglishPro</div>
            <div style={{ fontSize: 10, color: "rgba(255,180,50,0.5)", letterSpacing: 2, textTransform: "uppercase" }}>Academy</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 16 }}>🔥</span>
            <span style={{ color: "#ff8040", fontWeight: "bold", fontSize: 14 }}>{streak}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 16 }}>⚡</span>
            <span style={{ color: "#f0c060", fontWeight: "bold", fontSize: 14 }}>{xp}</span>
          </div>
          <div style={{
            background: "linear-gradient(135deg, rgba(255,180,50,0.2), rgba(255,120,40,0.2))",
            border: "1px solid rgba(255,180,50,0.4)",
            borderRadius: 20, padding: "3px 10px",
            fontSize: 12, color: "#f0c060", fontWeight: "bold"
          }}>{level}</div>
        </div>
      </div>

      {/* XP Progress Bar */}
      <div style={{ padding: "8px 20px 0", background: "rgba(10,10,26,0.95)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
          <span style={{ fontSize: 11, color: "rgba(255,180,50,0.5)" }}>Уровень {userLevel}</span>
          <span style={{ fontSize: 11, color: "rgba(255,180,50,0.5)" }}>{xp % xpToNextLevel}/{xpToNextLevel} XP</span>
        </div>
        <div style={{ height: 4, background: "rgba(255,180,50,0.1)", borderRadius: 2, overflow: "hidden" }}>
          <div style={{
            height: "100%", width: `${xpProgress}%`,
            background: "linear-gradient(90deg, #f0c060, #ff8040)",
            borderRadius: 2, transition: "width 0.5s ease"
          }} />
        </div>
      </div>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1, paddingBottom: 80 }}>
        {screen === "home" && <HomeScreen setScreen={setScreen} completedLessons={completedLessons} level={level} streak={streak} />}
        {screen === "test" && <LevelTest setScreen={setScreen} setLevel={setLevel} addXp={addXp} showNotif={showNotif} />}
        {screen === "grammar" && <GrammarScreen setScreen={setScreen} addXp={addXp} completedLessons={completedLessons} setCompletedLessons={setCompletedLessons} unlockAchievement={unlockAchievement} showNotif={showNotif} />}
        {screen === "vocab" && <VocabScreen setScreen={setScreen} addXp={addXp} vocabLearned={vocabLearned} setVocabLearned={setVocabLearned} unlockAchievement={unlockAchievement} />}
        {screen === "dialogue" && <DialogueScreen setScreen={setScreen} addXp={addXp} showNotif={showNotif} />}
        {screen === "profile" && <ProfileScreen setScreen={setScreen} xp={xp} streak={streak} level={level} userLevel={userLevel} unlockedAchievements={unlockedAchievements} completedLessons={completedLessons} vocabLearned={vocabLearned} />}
      </div>

      {/* Bottom Navigation */}
      <BottomNav screen={screen} setScreen={setScreen} />
    </div>
  );
}

// ============================================================
// HOME SCREEN
// ============================================================
function HomeScreen({ setScreen, completedLessons, level, streak }) {
  const modules = [
    { id: "test", icon: "🎯", title: "Тест уровня", desc: "Определи свой уровень", color: "#4a90d9", badge: level },
    { id: "grammar", icon: "📖", title: "Грамматика", desc: `${completedLessons.length}/${GRAMMAR_LESSONS.length} уроков`, color: "#e8a040" },
    { id: "vocab", icon: "🗂️", title: "Словарный запас", desc: `${VOCABULARY.length} слов • Карточки`, color: "#6ab04c" },
    { id: "dialogue", icon: "💬", title: "Диалоги", desc: "Разговорная практика", color: "#a855f7" },
  ];

  return (
    <div style={{ padding: 20 }}>
      {/* Welcome */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 3, textTransform: "uppercase", marginBottom: 6 }}>Добро пожаловать</div>
        <div style={{ fontSize: 26, fontWeight: "bold", color: "#e8e0d0", lineHeight: 1.2 }}>Продолжайте учить<br /><span style={{ color: "#f0c060" }}>английский язык</span> 🇬🇧</div>
      </div>

      {/* Daily streak card */}
      <div style={{
        background: "linear-gradient(135deg, rgba(255,80,0,0.15), rgba(255,150,0,0.1))",
        border: "1px solid rgba(255,120,0,0.3)",
        borderRadius: 16, padding: "16px 20px",
        marginBottom: 24, display: "flex", alignItems: "center", justifyContent: "space-between"
      }}>
        <div>
          <div style={{ fontSize: 13, color: "rgba(255,150,80,0.7)", marginBottom: 4 }}>Серия дней</div>
          <div style={{ fontSize: 28, fontWeight: "bold", color: "#ff8040" }}>🔥 {streak} дней</div>
          <div style={{ fontSize: 12, color: "rgba(255,150,80,0.5)", marginTop: 2 }}>Занимайтесь каждый день!</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ display: "flex", gap: 6 }}>
            {["Пн","Вт","Ср","Чт","Пт","Сб","Вс"].map((d, i) => (
              <div key={d} style={{
                width: 28, height: 28, borderRadius: 8,
                background: i < streak % 7 ? "linear-gradient(135deg, #ff6020, #ffa040)" : "rgba(255,100,0,0.1)",
                border: `1px solid ${i < streak % 7 ? "rgba(255,150,0,0.5)" : "rgba(255,100,0,0.2)"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 9, color: i < streak % 7 ? "#fff" : "rgba(255,100,0,0.4)", fontWeight: "bold"
              }}>{d}</div>
            ))}
          </div>
        </div>
      </div>

      {/* Modules grid */}
      <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>Модули обучения</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {modules.map(m => (
          <button key={m.id} onClick={() => setScreen(m.id)} style={{
            background: `linear-gradient(135deg, ${m.color}18, ${m.color}08)`,
            border: `1px solid ${m.color}40`,
            borderRadius: 16, padding: "18px 16px",
            textAlign: "left", cursor: "pointer", color: "#e8e0d0",
            transition: "all 0.2s ease", position: "relative", overflow: "hidden"
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.03)"; e.currentTarget.style.borderColor = m.color + "80"; }}
            onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.borderColor = m.color + "40"; }}
          >
            <div style={{ fontSize: 28, marginBottom: 8 }}>{m.icon}</div>
            <div style={{ fontSize: 14, fontWeight: "bold", color: m.color, marginBottom: 4 }}>{m.title}</div>
            <div style={{ fontSize: 11, color: "rgba(232,224,208,0.5)" }}>{m.desc}</div>
            {m.badge && (
              <div style={{
                position: "absolute", top: 10, right: 10,
                background: m.color + "30", border: `1px solid ${m.color}50`,
                borderRadius: 8, padding: "2px 6px", fontSize: 10, color: m.color, fontWeight: "bold"
              }}>{m.badge}</div>
            )}
          </button>
        ))}
      </div>

      {/* Quick tip */}
      <div style={{
        marginTop: 24,
        background: "rgba(100,180,255,0.06)",
        border: "1px solid rgba(100,180,255,0.15)",
        borderRadius: 12, padding: 16,
      }}>
        <div style={{ fontSize: 12, color: "rgba(100,180,255,0.6)", letterSpacing: 2, marginBottom: 6 }}>💡 СОВЕТ ДНЯ</div>
        <div style={{ fontSize: 13, color: "rgba(232,224,208,0.7)", lineHeight: 1.5 }}>
          Читайте на английском хотя бы 15 минут в день. Это значительно расширяет словарный запас и улучшает понимание грамматики.
        </div>
      </div>
    </div>
  );
}

// ============================================================
// LEVEL TEST
// ============================================================
function LevelTest({ setScreen, setLevel, addXp, showNotif }) {
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [done, setDone] = useState(false);
  const [result, setResult] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const q = LEVEL_TEST[current];

  const handleAnswer = (opt) => {
    if (showFeedback) return;
    setSelected(opt);
    setShowFeedback(true);
    setTimeout(() => {
      const newAnswers = [...answers, opt === q.answer];
      setAnswers(newAnswers);
      setShowFeedback(false);
      setSelected(null);
      if (current + 1 < LEVEL_TEST.length) {
        setCurrent(prev => prev + 1);
      } else {
        const score = newAnswers.filter(Boolean).length;
        let lvl = "A1";
        if (score >= 6) lvl = "C1";
        else if (score >= 5) lvl = "B2";
        else if (score >= 4) lvl = "B1";
        else if (score >= 3) lvl = "A2";
        setResult({ score, level: lvl });
        setLevel(lvl);
        setDone(true);
        addXp(50 + score * 10);
      }
    }, 800);
  };

  if (done && result) {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn setScreen={setScreen} target="home" />
        <div style={{ textAlign: "center", padding: "40px 20px" }}>
          <div style={{ fontSize: 80, marginBottom: 16 }}>🎓</div>
          <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 3, marginBottom: 8 }}>ВАШ УРОВЕНЬ</div>
          <div style={{
            fontSize: 64, fontWeight: "bold",
            background: "linear-gradient(135deg, #f0c060, #ff8040)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            marginBottom: 8
          }}>{result.level}</div>
          <div style={{ fontSize: 16, color: "rgba(232,224,208,0.6)", marginBottom: 24 }}>
            Правильных ответов: {result.score}/{LEVEL_TEST.length}
          </div>
          <div style={{
            background: "rgba(255,180,50,0.08)", border: "1px solid rgba(255,180,50,0.2)",
            borderRadius: 16, padding: 20, marginBottom: 24, textAlign: "left"
          }}>
            {[
              { lvl: "A1", desc: "Начинающий — базовые фразы" },
              { lvl: "A2", desc: "Элементарный — простые диалоги" },
              { lvl: "B1", desc: "Средний — свободное общение" },
              { lvl: "B2", desc: "Выше среднего — сложные темы" },
              { lvl: "C1", desc: "Продвинутый — почти как носитель" },
            ].map(({ lvl, desc }) => (
              <div key={lvl} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderBottom: "1px solid rgba(255,180,50,0.08)" }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 10,
                  background: lvl === result.level ? "linear-gradient(135deg, #f0c060, #ff8040)" : "rgba(255,180,50,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 12, fontWeight: "bold", color: lvl === result.level ? "#0a0a1a" : "#f0c060"
                }}>{lvl}</div>
                <span style={{ fontSize: 13, color: lvl === result.level ? "#e8e0d0" : "rgba(232,224,208,0.4)" }}>{desc}</span>
              </div>
            ))}
          </div>
          <ActionBtn onClick={() => setScreen("home")}>Начать обучение →</ActionBtn>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <BackBtn setScreen={setScreen} target="home" />
      <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 20 }}>ТЕСТ НА УРОВЕНЬ</div>

      {/* Progress */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 12, color: "rgba(255,180,50,0.4)" }}>
          <span>Вопрос {current + 1} из {LEVEL_TEST.length}</span>
          <span>Уровень: {q.level}</span>
        </div>
        <div style={{ height: 6, background: "rgba(255,180,50,0.1)", borderRadius: 3, overflow: "hidden" }}>
          <div style={{
            height: "100%", width: `${(current / LEVEL_TEST.length) * 100}%`,
            background: "linear-gradient(90deg, #f0c060, #ff8040)", borderRadius: 3, transition: "width 0.4s ease"
          }} />
        </div>
      </div>

      {/* Question */}
      <div style={{
        background: "rgba(255,180,50,0.06)", border: "1px solid rgba(255,180,50,0.15)",
        borderRadius: 16, padding: 24, marginBottom: 20, textAlign: "center"
      }}>
        <div style={{ fontSize: 18, color: "#e8e0d0", lineHeight: 1.6 }}>{q.q}</div>
      </div>

      {/* Options */}
      <div style={{ display: "grid", gap: 10 }}>
        {q.options.map(opt => {
          let bg = "rgba(255,180,50,0.06)";
          let border = "rgba(255,180,50,0.15)";
          let color = "#e8e0d0";
          if (showFeedback && selected === opt) {
            if (opt === q.answer) { bg = "rgba(100,200,100,0.15)"; border = "rgba(100,200,100,0.5)"; color = "#80e080"; }
            else { bg = "rgba(200,80,80,0.15)"; border = "rgba(200,80,80,0.5)"; color = "#e08080"; }
          }
          if (showFeedback && opt === q.answer && selected !== opt) { bg = "rgba(100,200,100,0.1)"; border = "rgba(100,200,100,0.4)"; }
          return (
            <button key={opt} onClick={() => handleAnswer(opt)} style={{
              background: bg, border: `1px solid ${border}`,
              borderRadius: 12, padding: "14px 20px",
              textAlign: "left", cursor: "pointer", color, fontSize: 15,
              transition: "all 0.2s ease"
            }}>{opt}</button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// GRAMMAR SCREEN
// ============================================================
function GrammarScreen({ setScreen, addXp, completedLessons, setCompletedLessons, unlockAchievement, showNotif }) {
  const [lesson, setLesson] = useState(null);
  const [stage, setStage] = useState("theory"); // theory | exercise
  const [exIdx, setExIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  if (!lesson) {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn setScreen={setScreen} target="home" />
        <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 20 }}>ГРАММАТИКА</div>
        <div style={{ display: "grid", gap: 12 }}>
          {GRAMMAR_LESSONS.map(l => {
            const isCompleted = completedLessons.includes(l.id);
            return (
              <button key={l.id} onClick={() => { setLesson(l); setStage("theory"); setExIdx(0); setScore(0); setDone(false); setSelected(null); }} style={{
                background: isCompleted ? "rgba(100,200,100,0.08)" : "rgba(255,180,50,0.06)",
                border: `1px solid ${isCompleted ? "rgba(100,200,100,0.3)" : "rgba(255,180,50,0.15)"}`,
                borderRadius: 16, padding: "18px 20px",
                textAlign: "left", cursor: "pointer", color: "#e8e0d0",
                display: "flex", alignItems: "center", gap: 16, transition: "all 0.2s"
              }}
                onMouseEnter={e => e.currentTarget.style.transform = "translateX(4px)"}
                onMouseLeave={e => e.currentTarget.style.transform = "translateX(0)"}
              >
                <div style={{ fontSize: 32 }}>{l.icon}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: "bold", color: isCompleted ? "#80e080" : "#f0c060", marginBottom: 3 }}>{l.title}</div>
                  <div style={{ fontSize: 12, color: "rgba(232,224,208,0.4)" }}>Уровень {l.level} • {l.exercises.length} упражнений</div>
                </div>
                <div style={{ fontSize: 18 }}>{isCompleted ? "✅" : "▶️"}</div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  if (done) {
    const perfect = score === lesson.exercises.length;
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div style={{ fontSize: 72, marginBottom: 16 }}>{perfect ? "🏆" : "👏"}</div>
        <div style={{ fontSize: 22, fontWeight: "bold", color: "#f0c060", marginBottom: 8 }}>
          {perfect ? "Отлично!" : "Хорошая работа!"}
        </div>
        <div style={{ fontSize: 15, color: "rgba(232,224,208,0.6)", marginBottom: 24 }}>
          Результат: {score}/{lesson.exercises.length}
        </div>
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          <button onClick={() => setLesson(null)} style={{
            background: "rgba(255,180,50,0.1)", border: "1px solid rgba(255,180,50,0.3)",
            borderRadius: 12, padding: "12px 24px", color: "#f0c060", cursor: "pointer", fontSize: 14
          }}>← К урокам</button>
          <ActionBtn onClick={() => setLesson(null)}>Продолжить</ActionBtn>
        </div>
      </div>
    );
  }

  if (stage === "theory") {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn onClick={() => setLesson(null)} />
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
          <span style={{ fontSize: 36 }}>{lesson.icon}</span>
          <div>
            <div style={{ fontSize: 20, fontWeight: "bold", color: "#f0c060" }}>{lesson.title}</div>
            <div style={{ fontSize: 12, color: "rgba(255,180,50,0.4)" }}>Уровень {lesson.level}</div>
          </div>
        </div>

        <div style={{ background: "rgba(100,180,255,0.06)", border: "1px solid rgba(100,180,255,0.15)", borderRadius: 16, padding: 20, marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: "rgba(100,180,255,0.6)", letterSpacing: 2, marginBottom: 10 }}>📚 ПРАВИЛО</div>
          <div style={{ fontSize: 14, color: "#e8e0d0", lineHeight: 1.7 }}>{lesson.theory}</div>
        </div>

        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 12 }}>✍️ ПРИМЕРЫ</div>
          {lesson.examples.map((ex, i) => (
            <div key={i} style={{
              background: "rgba(255,180,50,0.06)", border: "1px solid rgba(255,180,50,0.1)",
              borderRadius: 10, padding: "12px 16px", marginBottom: 8,
              fontSize: 14, color: "#e8e0d0", fontStyle: "italic"
            }}>"{ex}"</div>
          ))}
        </div>

        <ActionBtn onClick={() => setStage("exercise")}>Начать упражнения →</ActionBtn>
      </div>
    );
  }

  const ex = lesson.exercises[exIdx];
  return (
    <div style={{ padding: 20 }}>
      <BackBtn onClick={() => setStage("theory")} />
      <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 16 }}>УПРАЖНЕНИЕ {exIdx + 1}/{lesson.exercises.length}</div>

      <div style={{ height: 4, background: "rgba(255,180,50,0.1)", borderRadius: 2, marginBottom: 20 }}>
        <div style={{ height: "100%", width: `${((exIdx) / lesson.exercises.length) * 100}%`, background: "linear-gradient(90deg, #f0c060, #ff8040)", borderRadius: 2 }} />
      </div>

      <div style={{ background: "rgba(255,180,50,0.06)", border: "1px solid rgba(255,180,50,0.15)", borderRadius: 16, padding: 24, marginBottom: 20, textAlign: "center" }}>
        <div style={{ fontSize: 17, color: "#e8e0d0" }}>{ex.q}</div>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        {ex.options.map(opt => {
          let bg = "rgba(255,180,50,0.06)", border = "rgba(255,180,50,0.15)", color = "#e8e0d0";
          if (showFeedback && selected === opt) {
            if (opt === ex.answer) { bg = "rgba(100,200,100,0.15)"; border = "rgba(100,200,100,0.5)"; color = "#80e080"; }
            else { bg = "rgba(200,80,80,0.15)"; border = "rgba(200,80,80,0.5)"; color = "#e08080"; }
          }
          if (showFeedback && opt === ex.answer && selected !== opt) { bg = "rgba(100,200,100,0.08)"; border = "rgba(100,200,100,0.3)"; }
          return (
            <button key={opt} onClick={() => {
              if (showFeedback) return;
              setSelected(opt);
              setShowFeedback(true);
              const correct = opt === ex.answer;
              if (correct) setScore(s => s + 1);
              setTimeout(() => {
                setShowFeedback(false); setSelected(null);
                if (exIdx + 1 < lesson.exercises.length) {
                  setExIdx(i => i + 1);
                } else {
                  const finalScore = score + (correct ? 1 : 0);
                  setDone(true);
                  if (!completedLessons.includes(lesson.id)) {
                    setCompletedLessons(prev => [...prev, lesson.id]);
                    unlockAchievement("first_lesson");
                    if (lesson.id === GRAMMAR_LESSONS.length) unlockAchievement("all_grammar");
                  }
                  addXp(finalScore === lesson.exercises.length ? 100 : 60);
                  if (finalScore === lesson.exercises.length) unlockAchievement("perfect_quiz");
                }
              }, 900);
            }} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 12, padding: "14px 20px", textAlign: "left", cursor: "pointer", color, fontSize: 15, transition: "all 0.2s" }}>{opt}</button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// VOCABULARY SCREEN
// ============================================================
function VocabScreen({ setScreen, addXp, vocabLearned, setVocabLearned, unlockAchievement }) {
  const [mode, setMode] = useState("list"); // list | flashcard | quiz
  const [cardIdx, setCardIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizSelected, setQuizSelected] = useState(null);
  const [quizFeedback, setQuizFeedback] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [quizDone, setQuizDone] = useState(false);

  const word = VOCABULARY[cardIdx];

  const getQuizOptions = (idx) => {
    const correct = VOCABULARY[idx].translation;
    const others = VOCABULARY.filter((_, i) => i !== idx).map(v => v.translation).sort(() => Math.random() - 0.5).slice(0, 3);
    return [correct, ...others].sort(() => Math.random() - 0.5);
  };
  const [quizOptions] = useState(() => VOCABULARY.map((_, i) => getQuizOptions(i)));

  if (mode === "list") {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn setScreen={setScreen} target="home" />
        <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 6 }}>СЛОВАРНЫЙ ЗАПАС</div>
        <div style={{ fontSize: 12, color: "rgba(232,224,208,0.4)", marginBottom: 20 }}>Выучено: {vocabLearned.length}/{VOCABULARY.length} слов</div>

        <div style={{ display: "flex", gap: 10, marginBottom: 24 }}>
          <button onClick={() => { setMode("flashcard"); setCardIdx(0); setFlipped(false); }} style={{ flex: 1, background: "rgba(100,180,255,0.1)", border: "1px solid rgba(100,180,255,0.3)", borderRadius: 12, padding: "12px", color: "#60b0ff", cursor: "pointer", fontSize: 13 }}>🃏 Карточки</button>
          <button onClick={() => { setMode("quiz"); setQuizIdx(0); setQuizScore(0); setQuizDone(false); }} style={{ flex: 1, background: "rgba(168,85,247,0.1)", border: "1px solid rgba(168,85,247,0.3)", borderRadius: 12, padding: "12px", color: "#c084fc", cursor: "pointer", fontSize: 13 }}>🧩 Тест</button>
        </div>

        <div style={{ display: "grid", gap: 10 }}>
          {VOCABULARY.map((v, i) => {
            const learned = vocabLearned.includes(i);
            return (
              <div key={i} style={{
                background: learned ? "rgba(100,200,100,0.06)" : "rgba(255,180,50,0.04)",
                border: `1px solid ${learned ? "rgba(100,200,100,0.2)" : "rgba(255,180,50,0.1)"}`,
                borderRadius: 12, padding: "14px 16px",
                display: "flex", alignItems: "center", justifyContent: "space-between"
              }}>
                <div>
                  <div style={{ fontSize: 15, color: "#f0c060", fontWeight: "bold" }}>{v.word}</div>
                  <div style={{ fontSize: 13, color: "rgba(232,224,208,0.5)", marginTop: 2 }}>{v.translation}</div>
                  <div style={{ fontSize: 11, color: "rgba(232,224,208,0.3)", marginTop: 3, fontStyle: "italic" }}>{v.example}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                  <div style={{
                    background: "rgba(255,180,50,0.1)", border: "1px solid rgba(255,180,50,0.2)",
                    borderRadius: 6, padding: "2px 6px", fontSize: 10, color: "rgba(255,180,50,0.6)"
                  }}>{v.level}</div>
                  <button onClick={() => {
                    if (!learned) {
                      const newLearned = [...vocabLearned, i];
                      setVocabLearned(newLearned);
                      addXp(10);
                      if (newLearned.length >= 10) unlockAchievement("vocab_10");
                    }
                  }} style={{
                    background: learned ? "rgba(100,200,100,0.15)" : "rgba(255,180,50,0.08)",
                    border: `1px solid ${learned ? "rgba(100,200,100,0.3)" : "rgba(255,180,50,0.2)"}`,
                    borderRadius: 8, padding: "4px 10px", fontSize: 11,
                    color: learned ? "#80e080" : "#f0c060", cursor: "pointer"
                  }}>{learned ? "✓ Знаю" : "Выучить"}</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (mode === "flashcard") {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn onClick={() => setMode("list")} />
        <div style={{ fontSize: 13, color: "rgba(100,180,255,0.5)", letterSpacing: 2, marginBottom: 20 }}>КАРТОЧКИ • {cardIdx + 1}/{VOCABULARY.length}</div>

        <div style={{ height: 4, background: "rgba(100,180,255,0.1)", borderRadius: 2, marginBottom: 24 }}>
          <div style={{ height: "100%", width: `${((cardIdx + 1) / VOCABULARY.length) * 100}%`, background: "linear-gradient(90deg, #4090e0, #60b0ff)", borderRadius: 2 }} />
        </div>

        <div onClick={() => setFlipped(f => !f)} style={{
          background: flipped ? "linear-gradient(135deg, rgba(100,200,100,0.1), rgba(100,200,100,0.05))" : "linear-gradient(135deg, rgba(100,180,255,0.1), rgba(100,180,255,0.05))",
          border: `1px solid ${flipped ? "rgba(100,200,100,0.3)" : "rgba(100,180,255,0.3)"}`,
          borderRadius: 24, padding: "60px 30px", textAlign: "center", cursor: "pointer",
          minHeight: 220, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          marginBottom: 24, transition: "all 0.3s ease"
        }}>
          {!flipped ? (
            <>
              <div style={{ fontSize: 36, fontWeight: "bold", color: "#60b0ff", marginBottom: 12 }}>{word.word}</div>
              <div style={{ fontSize: 12, color: "rgba(100,180,255,0.4)", letterSpacing: 2 }}>НАЖМИТЕ ДЛЯ ПЕРЕВОДА</div>
            </>
          ) : (
            <>
              <div style={{ fontSize: 28, color: "#80e080", marginBottom: 8 }}>{word.translation}</div>
              <div style={{ fontSize: 14, color: "rgba(232,224,208,0.5)", fontStyle: "italic", marginTop: 8 }}>{word.example}</div>
            </>
          )}
        </div>

        <div style={{ display: "flex", gap: 12 }}>
          <button onClick={() => { if (cardIdx > 0) { setCardIdx(i => i - 1); setFlipped(false); } }} style={{ flex: 1, background: "rgba(255,180,50,0.06)", border: "1px solid rgba(255,180,50,0.15)", borderRadius: 12, padding: 14, color: "#f0c060", cursor: "pointer", fontSize: 14 }}>← Назад</button>
          <button onClick={() => { if (cardIdx < VOCABULARY.length - 1) { setCardIdx(i => i + 1); setFlipped(false); } else { setMode("list"); addXp(30); } }} style={{ flex: 2, background: "linear-gradient(135deg, rgba(100,180,255,0.2), rgba(100,180,255,0.1))", border: "1px solid rgba(100,180,255,0.4)", borderRadius: 12, padding: 14, color: "#60b0ff", cursor: "pointer", fontSize: 14, fontWeight: "bold" }}>
            {cardIdx < VOCABULARY.length - 1 ? "Следующее →" : "✓ Готово!"}
          </button>
        </div>
      </div>
    );
  }

  // Quiz mode
  if (quizDone) {
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div style={{ fontSize: 72, marginBottom: 16 }}>{quizScore >= 8 ? "🏆" : "👏"}</div>
        <div style={{ fontSize: 22, fontWeight: "bold", color: "#f0c060", marginBottom: 8 }}>Тест завершён!</div>
        <div style={{ fontSize: 15, color: "rgba(232,224,208,0.6)", marginBottom: 24 }}>Результат: {quizScore}/{VOCABULARY.length}</div>
        <ActionBtn onClick={() => setMode("list")}>← К словарю</ActionBtn>
      </div>
    );
  }

  const qWord = VOCABULARY[quizIdx];
  const opts = quizOptions[quizIdx];
  return (
    <div style={{ padding: 20 }}>
      <BackBtn onClick={() => setMode("list")} />
      <div style={{ fontSize: 13, color: "rgba(168,85,247,0.5)", letterSpacing: 2, marginBottom: 16 }}>ТЕСТ СЛОВАРЯ • {quizIdx + 1}/{VOCABULARY.length}</div>

      <div style={{ height: 4, background: "rgba(168,85,247,0.1)", borderRadius: 2, marginBottom: 20 }}>
        <div style={{ height: "100%", width: `${(quizIdx / VOCABULARY.length) * 100}%`, background: "linear-gradient(90deg, #8b5cf6, #c084fc)", borderRadius: 2 }} />
      </div>

      <div style={{ background: "rgba(168,85,247,0.08)", border: "1px solid rgba(168,85,247,0.2)", borderRadius: 16, padding: 32, textAlign: "center", marginBottom: 20 }}>
        <div style={{ fontSize: 12, color: "rgba(192,132,252,0.5)", marginBottom: 8 }}>Выберите перевод:</div>
        <div style={{ fontSize: 28, fontWeight: "bold", color: "#c084fc" }}>{qWord.word}</div>
      </div>

      <div style={{ display: "grid", gap: 10 }}>
        {opts.map((opt, i) => {
          let bg = "rgba(168,85,247,0.06)", border = "rgba(168,85,247,0.2)", color = "#e8e0d0";
          if (quizFeedback && quizSelected === opt) {
            if (opt === qWord.translation) { bg = "rgba(100,200,100,0.15)"; border = "rgba(100,200,100,0.5)"; color = "#80e080"; }
            else { bg = "rgba(200,80,80,0.15)"; border = "rgba(200,80,80,0.5)"; color = "#e08080"; }
          }
          if (quizFeedback && opt === qWord.translation && quizSelected !== opt) { bg = "rgba(100,200,100,0.08)"; border = "rgba(100,200,100,0.3)"; }
          return (
            <button key={i} onClick={() => {
              if (quizFeedback) return;
              setQuizSelected(opt);
              setQuizFeedback(true);
              const correct = opt === qWord.translation;
              if (correct) setQuizScore(s => s + 1);
              setTimeout(() => {
                setQuizFeedback(false); setQuizSelected(null);
                if (quizIdx + 1 < VOCABULARY.length) setQuizIdx(i => i + 1);
                else { setQuizDone(true); addXp(quizScore >= 8 ? 150 : 80); }
              }, 800);
            }} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 12, padding: "14px 20px", textAlign: "left", cursor: "pointer", color, fontSize: 14, transition: "all 0.2s" }}>{opt}</button>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// DIALOGUE SCREEN
// ============================================================
function DialogueScreen({ setScreen, addXp, showNotif }) {
  const [selected, setSelected] = useState(null);
  const [lineIdx, setLineIdx] = useState(0);
  const [done, setDone] = useState(false);

  if (!selected) {
    return (
      <div style={{ padding: 20 }}>
        <BackBtn setScreen={setScreen} target="home" />
        <div style={{ fontSize: 13, color: "rgba(168,85,247,0.5)", letterSpacing: 2, marginBottom: 20 }}>ДИАЛОГИ</div>
        <div style={{ display: "grid", gap: 12 }}>
          {DIALOGUES.map(d => (
            <button key={d.id} onClick={() => { setSelected(d); setLineIdx(0); setDone(false); }} style={{
              background: "rgba(168,85,247,0.06)", border: "1px solid rgba(168,85,247,0.2)",
              borderRadius: 16, padding: "20px", textAlign: "left", cursor: "pointer", color: "#e8e0d0",
              transition: "all 0.2s"
            }}
              onMouseEnter={e => e.currentTarget.style.borderColor = "rgba(168,85,247,0.5)"}
              onMouseLeave={e => e.currentTarget.style.borderColor = "rgba(168,85,247,0.2)"}
            >
              <div style={{ fontSize: 20, fontWeight: "bold", color: "#c084fc", marginBottom: 6 }}>{d.title}</div>
              <div style={{ fontSize: 12, color: "rgba(192,132,252,0.5)" }}>Уровень {d.level} • {d.lines.length} реплик</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (done) {
    return (
      <div style={{ padding: 20, textAlign: "center" }}>
        <div style={{ fontSize: 72, marginBottom: 16 }}>💬</div>
        <div style={{ fontSize: 22, fontWeight: "bold", color: "#c084fc", marginBottom: 8 }}>Диалог завершён!</div>
        <div style={{ fontSize: 14, color: "rgba(232,224,208,0.5)", marginBottom: 24 }}>Отличная практика разговорного английского!</div>
        <ActionBtn onClick={() => setSelected(null)}>← К диалогам</ActionBtn>
      </div>
    );
  }

  const line = selected.lines[lineIdx];
  const isYou = line.speaker === "You";

  return (
    <div style={{ padding: 20 }}>
      <BackBtn onClick={() => setSelected(null)} />
      <div style={{ fontSize: 16, fontWeight: "bold", color: "#c084fc", marginBottom: 6 }}>{selected.title}</div>
      <div style={{ height: 4, background: "rgba(168,85,247,0.1)", borderRadius: 2, marginBottom: 20 }}>
        <div style={{ height: "100%", width: `${(lineIdx / selected.lines.length) * 100}%`, background: "linear-gradient(90deg, #8b5cf6, #c084fc)", borderRadius: 2 }} />
      </div>

      <div style={{ minHeight: 320, marginBottom: 20 }}>
        {selected.lines.slice(0, lineIdx + 1).map((l, i) => {
          const isU = l.speaker === "You";
          return (
            <div key={i} style={{ display: "flex", justifyContent: isU ? "flex-end" : "flex-start", marginBottom: 12 }}>
              <div style={{
                maxWidth: "78%",
                background: isU ? "linear-gradient(135deg, rgba(168,85,247,0.2), rgba(168,85,247,0.1))" : "rgba(255,255,255,0.05)",
                border: `1px solid ${isU ? "rgba(168,85,247,0.4)" : "rgba(255,255,255,0.1)"}`,
                borderRadius: isU ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                padding: "12px 16px",
              }}>
                <div style={{ fontSize: 10, color: isU ? "rgba(192,132,252,0.6)" : "rgba(232,224,208,0.3)", marginBottom: 4, letterSpacing: 1 }}>{l.speaker.toUpperCase()}</div>
                <div style={{ fontSize: 14, color: isU ? "#d0a0ff" : "#e8e0d0", lineHeight: 1.5 }}>{l.text}</div>
              </div>
            </div>
          );
        })}
      </div>

      <button onClick={() => {
        if (lineIdx + 1 < selected.lines.length) setLineIdx(i => i + 1);
        else { setDone(true); addXp(80); }
      }} style={{
        width: "100%",
        background: "linear-gradient(135deg, rgba(168,85,247,0.3), rgba(168,85,247,0.15))",
        border: "1px solid rgba(168,85,247,0.5)",
        borderRadius: 14, padding: "16px", cursor: "pointer",
        color: "#d0a0ff", fontSize: 15, fontWeight: "bold", fontFamily: "Georgia, serif"
      }}>
        {lineIdx + 1 < selected.lines.length ? (isYou ? `💬 Ответить: "${selected.lines[lineIdx + 1]?.text}"` : "Продолжить →") : "✓ Завершить диалог"}
      </button>
    </div>
  );
}

// ============================================================
// PROFILE SCREEN
// ============================================================
function ProfileScreen({ setScreen, xp, streak, level, userLevel, unlockedAchievements, completedLessons, vocabLearned }) {
  const stats = [
    { label: "Уровень", value: level, icon: "🎓" },
    { label: "XP всего", value: xp, icon: "⚡" },
    { label: "Серия дней", value: `${streak} 🔥`, icon: "📅" },
    { label: "Уроков", value: completedLessons.length, icon: "📖" },
    { label: "Слов выучено", value: vocabLearned.length, icon: "🗂️" },
    { label: "Ур. пользователя", value: userLevel, icon: "⭐" },
  ];

  return (
    <div style={{ padding: 20 }}>
      <div style={{ textAlign: "center", padding: "20px 0 28px" }}>
        <div style={{
          width: 80, height: 80, borderRadius: "50%", margin: "0 auto 12px",
          background: "linear-gradient(135deg, rgba(255,180,50,0.3), rgba(255,100,0,0.3))",
          border: "2px solid rgba(255,180,50,0.5)",
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36
        }}>👤</div>
        <div style={{ fontSize: 20, fontWeight: "bold", color: "#f0c060" }}>Мой профиль</div>
        <div style={{ fontSize: 13, color: "rgba(255,180,50,0.4)", marginTop: 4 }}>Уровень {userLevel} • {level}</div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 24 }}>
        {stats.map((s, i) => (
          <div key={i} style={{ background: "rgba(255,180,50,0.06)", border: "1px solid rgba(255,180,50,0.12)", borderRadius: 12, padding: "14px 10px", textAlign: "center" }}>
            <div style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</div>
            <div style={{ fontSize: 16, fontWeight: "bold", color: "#f0c060" }}>{s.value}</div>
            <div style={{ fontSize: 10, color: "rgba(255,180,50,0.4)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Achievements */}
      <div style={{ fontSize: 13, color: "rgba(255,180,50,0.5)", letterSpacing: 2, marginBottom: 14 }}>ДОСТИЖЕНИЯ</div>
      <div style={{ display: "grid", gap: 10 }}>
        {ACHIEVEMENTS.map(a => {
          const unlocked = unlockedAchievements.includes(a.id);
          return (
            <div key={a.id} style={{
              background: unlocked ? "rgba(255,180,50,0.08)" : "rgba(255,255,255,0.02)",
              border: `1px solid ${unlocked ? "rgba(255,180,50,0.3)" : "rgba(255,255,255,0.06)"}`,
              borderRadius: 12, padding: "14px 16px",
              display: "flex", alignItems: "center", gap: 14, opacity: unlocked ? 1 : 0.45
            }}>
              <div style={{ fontSize: 28 }}>{a.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: "bold", color: unlocked ? "#f0c060" : "rgba(232,224,208,0.4)" }}>{a.title}</div>
                <div style={{ fontSize: 12, color: "rgba(232,224,208,0.3)" }}>{a.desc}</div>
              </div>
              <div style={{
                background: unlocked ? "rgba(255,180,50,0.15)" : "transparent",
                border: `1px solid ${unlocked ? "rgba(255,180,50,0.3)" : "rgba(255,255,255,0.05)"}`,
                borderRadius: 8, padding: "3px 8px", fontSize: 11, color: unlocked ? "#f0c060" : "rgba(232,224,208,0.2)"
              }}>+{a.xp} XP</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// SHARED COMPONENTS
// ============================================================
function BackBtn({ setScreen, target, onClick }) {
  return (
    <button onClick={onClick || (() => setScreen(target))} style={{
      background: "transparent", border: "none", color: "rgba(255,180,50,0.5)",
      cursor: "pointer", fontSize: 13, padding: "0 0 16px", display: "flex", alignItems: "center", gap: 6
    }}>← Назад</button>
  );
}

function ActionBtn({ onClick, children }) {
  return (
    <button onClick={onClick} style={{
      width: "100%",
      background: "linear-gradient(135deg, rgba(255,180,50,0.25), rgba(255,100,0,0.2))",
      border: "1px solid rgba(255,180,50,0.5)",
      borderRadius: 14, padding: "16px",
      color: "#f0c060", fontSize: 15, fontWeight: "bold",
      cursor: "pointer", fontFamily: "Georgia, serif",
      transition: "all 0.2s ease"
    }}
      onMouseEnter={e => e.currentTarget.style.background = "linear-gradient(135deg, rgba(255,180,50,0.35), rgba(255,100,0,0.3))"}
      onMouseLeave={e => e.currentTarget.style.background = "linear-gradient(135deg, rgba(255,180,50,0.25), rgba(255,100,0,0.2))"}
    >{children}</button>
  );
}

function BottomNav({ screen, setScreen }) {
  const items = [
    { id: "home", icon: "🏠", label: "Главная" },
    { id: "grammar", icon: "📖", label: "Грамматика" },
    { id: "vocab", icon: "🗂️", label: "Слова" },
    { id: "dialogue", icon: "💬", label: "Диалоги" },
    { id: "profile", icon: "👤", label: "Профиль" },
  ];
  return (
    <div style={{
      position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
      width: "100%", maxWidth: 480,
      background: "rgba(10,10,26,0.97)", backdropFilter: "blur(20px)",
      borderTop: "1px solid rgba(255,180,50,0.12)",
      display: "flex", justifyContent: "space-around", padding: "8px 0 12px",
      zIndex: 200
    }}>
      {items.map(item => {
        const active = screen === item.id || (item.id === "home" && screen === "test");
        return (
          <button key={item.id} onClick={() => setScreen(item.id)} style={{
            background: "transparent", border: "none", cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
            padding: "4px 10px", borderRadius: 10,
            transition: "all 0.2s"
          }}>
            <span style={{ fontSize: 20, filter: active ? "none" : "grayscale(0.8) opacity(0.5)" }}>{item.icon}</span>
            <span style={{ fontSize: 9, color: active ? "#f0c060" : "rgba(232,224,208,0.3)", letterSpacing: 0.5, fontFamily: "Georgia, serif" }}>{item.label}</span>
            {active && <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#f0c060" }} />}
          </button>
        );
      })}
    </div>
  );
}
